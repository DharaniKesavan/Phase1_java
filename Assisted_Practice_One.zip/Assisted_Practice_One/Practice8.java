package Assisted_Practice_One;

public class Practice8 {
		public static void main(String[] args) {
			//String implementation
			String s1="JavaWorld";
			String s2="Javaworld";
			
			System.out.println("Strings :");
			System.out.println("Length = "+s1.length());
			System.out.println("Compare = "+s2.compareTo(s1));
			System.out.println("Equal = "+s1.equals(s2));
			System.out.println("LowerCase = "+s1.toLowerCase());
			System.out.println("UpperCase = "+s2.toUpperCase()); 
			System.out.println("Empty string = "+s2.isEmpty());
			System.out.println("Substring = "+s1.substring(4));
			System.out.println("Replaced string = "+s2.replace("Java","Python"));
			System.out.println("----------------------------------------");

			//StringBuffer implementation
			StringBuffer sb = new StringBuffer("Get Started");
			System.out.println("StringBuffer :");
			System.out.println("Append = "+sb.append(" Folks"));
			System.out.println("Insert = "+sb.insert(0,"Let's "));			
			System.out.println("Replace = "+sb.replace(18,23,"Guys"));
			System.out.println("Delete = "+sb.delete(0,6));
			System.out.println("Reverse = "+sb.reverse());
			System.out.println("CharAt = "+sb.charAt(9));
			System.out.println("----------------------------------------");
			
			//StringBuilder implementation
			StringBuilder sr =new StringBuilder("New Beginning");
			System.out.println("StringBuilder :");
			System.out.println("Append = "+sr.append(" 2022"));
			System.out.println("Insert = "+sr.insert(18,"!!!"));			
			System.out.println("Replace = "+sr.replace(18,21,"%%%"));
			System.out.println("Delete = "+sr.delete(18,21));
			System.out.println("Reverse = "+sr.reverse());
			System.out.println("CharAt = "+sb.charAt(10));
			System.out.println("----------------------------------------");
			
					
			//Conversion of Strings to StringBuffer and StringBuilder	
			String s3 = "Welcome"; 
			System.out.println("Conversion of Strings :");
	        // conversion from String to StringBuffer 
	        StringBuffer sb1 = new StringBuffer(s3); 
	        sb1.insert(7,"!!!");
	        System.out.println("StringBuffer = "+sb1); 
	          
	        // conversion from String to StringBuilder 
	        StringBuilder sr1 = new StringBuilder(s3); 
	        sr1.append("Family"); 
	        System.out.println("StringBuilder = "+sr1);              		
		}
	}
