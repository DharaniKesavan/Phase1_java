package Assisted_Practice_One;

public class Practice1 {		//typecasting

		public static void main(String args[]){
			System.out.println("Implicit Typecasting---");
			short s = 45;
			System.out.println("short value of s = "+s);
			int a1 = s;
			System.out.println("int value of s= "+a1);
			long l1 = s;
			System.out.println("long value of s = "+l1);
			float f1 = s;
			System.out.println("float value of s = "+f1);
			double d1 = s;
			System.out.println("double value of s = "+d1);
			System.out.println("-----------------------------------------");
			char c1 = 'R';
			System.out.println("char value of c1 = "+c1);
			int a2 = c1;
			System.out.println("int value of c1 = "+a2);
			long l2 = c1;
			System.out.println("long value of c1 = "+l2);
			float f2 = c1;
			System.out.println("float value of c1 = "+f2);
			double d2 = c1;
			System.out.println("double value of c1 = "+d2);
			System.out.println("-----------------------------------------");
			
			System.out.println("Explicit Typecasting---");
			double d3 = 43.56755489;
			System.out.println("double value of d1 = "+d3);
			int a3 = (int)d3;
			System.out.println("int value of d1 = "+a3);
			float f3 = (float)d3;
			System.out.println("float value of d1 = "+f3);
			long l3 = (long)d3;
			System.out.println("long value of d1 = "+l3);
			short s1 = (short)d3;
			System.out.println("short value of d1 = "+s1);
			System.out.println("-----------------------------------------");
			int a4 = 78;
			System.out.println("int value of a4 = "+a4);
			short s2 = (short)a4;
			System.out.println("short value of a4 = "+s2);
			char c2 = (char)a4;
			System.out.println("char value of a4 = "+c2);
		}
	}

