package Assisted_Practice_One;

public class Practice4 {
	int count;
	String gender;
	String name;
	int age;
	int id;
	Practice4(){}									//default constructor
	void display1(){
		System.out.println("Count = "+count+"\n"+"Gender = "+gender);
	}
	
	Practice4(String name,int age){				//parameterized constructor
		this.name = name;
		this.age = age;
	}
	void display2(){
		System.out.println("1.Name = "+name+"\n"+"2.Age = "+age);
	}
	
	Practice4(String name,int age,int id){
		this.name = name;
		this.age = age;
		this.id = id;
	}
	void display3(){
		System.out.println("1.Name = "+name+"\n"+"2.Age = "+age+"\n"+"3.Id = "+id);
	}
	
	public static void main(String args[]){
		Practice4 p1 = new Practice4();
		Practice4 p2 = new Practice4("Raja",20);
		Practice4 p3 = new Practice4("Priya",25,3388);
		p1.display1();	
		p2.display2();	
		p3.display3();	
	}
}
