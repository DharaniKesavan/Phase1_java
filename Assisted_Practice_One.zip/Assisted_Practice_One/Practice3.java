package Assisted_Practice_One;

public class Practice3{					//methods
	int total = 10;
		protected int addition(int a,int b){
			int c = a+b;
			return c;
		}
		public int area(int a){
			int aos = a*a;
			return aos;
		}
		public float area(float l,float w){
			float aor = l*w;
			return aor;
		}
		public static void main(String args[]){
			Practice3 p = new Practice3();
			System.out.println("Total value = "+p.total);
			System.out.println("Addition = "+p.addition(2,3));		
			System.out.println("Area of square = "+p.area(6));			//method overloading
			System.out.println("Area of rectangle = "+p.area(5.0f,6.0f));
		}
}
