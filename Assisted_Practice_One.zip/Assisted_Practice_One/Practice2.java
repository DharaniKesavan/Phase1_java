package Assisted_Practice_One;		//Access modifier
			
	//default modifier
	class Default{
		void display(){
			System.out.println("Default class");//can't able to access outside the package
		}
	}
	//private modifier
	class Private{
		private void display(){
			System.out.println("Private class");
		}
	}
	//protected modifier
	class Protected{
		protected void display(){
			System.out.println("Protected class");
		}
	}
	//public modifier
	class Public{
		public void display(){
			System.out.println("Public class");
		}
	}

	public class Practice2 extends Protected {
		public static void main(String args[]){
			Default a1 = new Default();
			Private a2 = new Private();
			Protected a3 = new Protected();
			Public a4 = new Public();
			a1.display();
		//	a2.display(); --->Private method
			a3.display();
			a4.display();	
		}
	}

