package Assisted_Practice_One;

class Subject{
	int mark = 99;
	class Maths{										//Inner class
		void display(){
			System.out.println("Maths mark = "+mark);
		}
	}
	void calculate(){
		class percentage{								//method local inner class
			void result(int total){
				float per = ((float)total/500)*100;
				System.out.println("Result = "+per);
			}
		}
		percentage p = new percentage();
		p.result(495);
	}
}

public class Practice7 {
	public static void main(String args[]){
		Subject s = new Subject();
		Subject.Maths m = s.new Maths();
		m.display();
		s.calculate();
	}
}
