package Assisted_Practice_One;

import java.util.ArrayList; 
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Vector;

public class Practice5 {						//collections
	public static void main(String[] args){
		//ArrayList
		ArrayList<String> al=new ArrayList<String>();  
		al.add("How");
		al.add("are");
		al.add("you");
		System.out.println("Arraylist = "+al);
		
		al.add(3,"sir");
		System.out.println("New Arraylist = "+al);
		System.out.println("Size of Arraylist = "+al.size()); 
		System.out.println("element at position 2 = "+ al.get(2));
		al.remove(3);
        System.out.println("Remove the element at position 3 = "+al);
        Collections.reverse(al);
        System.out.println("Reverse of arraylist = "+ al); 
        System.out.println("Is it contains How = "+al.contains("How"));
        System.out.println("-------------------------------------------------");
        
        //LinkedList
        LinkedList<String> ll = new LinkedList<String>();  
        ll.add("Sunday");
        ll.add("Monday");
        ll.add("Tuesday");
        ll.add("Wednesday");      
        ll.add(4,"Thursday");
        ll.addFirst("Hello");
        
        System.out.println("LinkedList = "+ll);
        Iterator<String> itr = ll.iterator();
        while(itr.hasNext()) {
        System.out.println("LinkedList = "+itr.next());
        }
        System.out.println("Size of the linked list = "+ll.size());
        System.out.println("Is LinkedList empty? = "+ll.isEmpty());
        System.out.println("Is it contains Friday = "+ll.contains("Friday"));
        System.out.println("-------------------------------------------------");
        
        //Vector
        Vector<String> v = new Vector<String>();
        v.add("Namakkal");
        v.add("Chennai");
        v.add("Coimbatore");      
        v.add(3,"Salem");
        System.out.println("Vector = "+v);
        System.out.println("Size of the Vector = "+v.size());
        System.out.println("-------------------------------------------------");
        
        //HashSet
        HashSet<Integer> hs = new HashSet<Integer>();		
		hs.add(10);
		hs.add(20);
		hs.add(30);
		hs.add(40);
				
		System.out.println("Hashset = "+hs);
		System.out.println("Size of Hashset = "+ hs.size());	
		System.out.println("Is it contains 20 = " + hs.contains(20));		
		System.out.println("Is hashset empty =  " + hs.isEmpty());
		hs.remove(30);
		System.out.println("Remove the element 30 = "+hs);
		System.out.println("-------------------------------------------------");
	    
	    //LinkedHashSet
		LinkedHashSet<Integer> lhs = new LinkedHashSet<Integer>();  
		lhs.add(11);
		lhs.add(22);
		lhs.add(33);
		lhs.add(44);
		System.out.println("LinkedHashset = "+lhs);
		System.out.println("GetClass = " +lhs.getClass());
		System.out.println("-------------------------------------------------");
		
		//PriorityQueue
		PriorityQueue<String> q = new PriorityQueue<String>();  
		q.add("Lily");  
		q.add("Jasmine");  
		q.add("Lotus");  
		q.add("Sunflower");   
		
		System.out.println("PriorityQueue = "+q);		
		System.out.println("Head using element = "+q.element());  
		System.out.println("Head using peek = "+q.peek()); 
	}
}
