package Assisted_Practice_One;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class Practice6 {							//Map
	public static void main(String[] args){
		//HashMap
		HashMap<Integer,String> hm = new HashMap<Integer,String>();		
        hm.put(1,"One");
        hm.put(2,"Two");
        hm.put(3,"Three");
        hm.put(4,"Four");
        hm.put(5,"Five");
		
        System.out.println("Hashmap : "+hm);
        System.out.println("Size of the HashMap = "+hm.size());
        System.out.println("Value of 3 key = "+hm.get(3));
        System.out.println("Is HashMap empty = "+hm.isEmpty());
        System.out.println("Is it contains Two as value = "+hm.containsValue("Two"));
        hm.remove(1);
        System.out.println("After removing key 1 : "+hm);
        System.out.println("-----------------------------------------------");
        
        // LinkedHashMap
        LinkedHashMap<Integer, String> lhm = new LinkedHashMap<Integer, String>();       
        lhm.put(5,"India");
        lhm.put(6,"Russia");
        lhm.put(7, new String("America"));
        lhm.put(8, new String("Japan"));
 
        System.out.println("LinkedHashMap : " +lhm);
        System.out.println("Size of the LinkedHashMap = " +lhm.size());
        System.out.println("Is LinkedHashMap empty = " +lhm.isEmpty());
        System.out.println("Is it contains 2 as key = " +lhm.containsKey(2));
        System.out.println("-----------------------------------------------");
        
        //Hashtable
        Hashtable<Integer,String> ht = new Hashtable<Integer,String>();
        ht.put(11,"Google");
        ht.put(22,"Microsoft");
        ht.put(33,"Oracle");
		ht.put(44,"Amazon");
		ht.put(55,"Flipkart");
		
        System.out.println("Hashtable: ");
        for(Integer key: ht.keySet()){
			System.out.println(key  +" = "+ ht.get(key));
        }
        System.out.println("Value of key 44 = "+ht.get(44));
        System.out.println("Size of the Hashtable =  "+ht.size());
        System.out.println("-----------------------------------------------");
        
        // TreeMap
        TreeMap<String, Integer> tm = new TreeMap<String, Integer>();
        tm.put("Apple",99);
        tm.put("Samsung",80);
        tm.put("Honor",85);
        
        System.out.println("Treemap: ");
        for(String key: tm.keySet()){
			System.out.println(key  +" = "+ tm.get(key));
        }
        System.out.println("Value of Key 'Apple' = "+ht.get("Apple"));
        System.out.println("Size of the Treemap =  "+ht.size());
	}
}
