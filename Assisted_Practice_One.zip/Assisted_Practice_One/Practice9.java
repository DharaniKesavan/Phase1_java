package Assisted_Practice_One;

public class Practice9 {
	 public static void main(String[] args) {  
		 //1D array
		 int x[]= {5,7,9,10,42};
		 System.out.println("1D Array elements: ");
		 for(int i=0;i<x.length;i++) {
			 System.out.println("x["+i+"] = "+x[i]);
		 }
		 
		 //2D array
		 int[][] y = { { 4, 2, 8, 16 }, { 3, 9, 15, 27 } }; 
		 System.out.println("2D Array elements: ");
	     for (int i = 0; i < y.length; i++) {                
	            for (int j = 0; j < y[0].length; j++) { 
	                System.out.print("y["+i+"]["+j+"] = "+y[i][j]+"\n"); 
	            } 
	     } 
	 } 
}
