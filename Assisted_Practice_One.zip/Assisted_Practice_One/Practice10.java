package Assisted_Practice_One;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Practice10 {									//Regular Expressions
	public static void main(String[] args) {
		    Pattern pattern = Pattern.compile("Happy");
		    Matcher matcher = pattern.matcher("Happy Journey");
		    boolean matchFound = matcher.find();
		    System.out.println("Is 1st pattern matched = ");
		    if(matchFound) 
		      System.out.println("Match found");
		    else 
		      System.out.println("Match not found");
		  
		    System.out.println("Is 2nd pattern matched = "+Pattern.matches("[amn]", "a"));
		    System.out.println("Is ? quantifier pattern match = "+Pattern.matches("[amn]?", "aaa"));	//comes one time
	        System.out.println("Is + quantifier pattern match = "+Pattern.matches("[amn]+", "aaa"));	//once or more times
	        System.out.println("Is * quantifier pattern match = "+Pattern.matches("[amn]*", "ammna"));	//may come zero or more times
	        
	        System.out.println("Is digit pattern match = "+Pattern.matches("\\d", "abc"));  //d means digit 
	        System.out.println("Is digit pattern match = "+Pattern.matches("\\d", "1"));
	        System.out.println("Is non-digit pattern match = "+Pattern.matches("\\D", "4443")); //D means non-digit 
	        System.out.println("Is non-digit pattern match = "+Pattern.matches("\\D", "m"));
		  }
	}

