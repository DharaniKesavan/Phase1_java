import { Component, OnInit } from '@angular/core';
import { Directive, ElementRef, Renderer2 } from '@angular/core';

@Directive({                                        //AssistedPractice 7
  selector: '[appChangeColor]' // Directive selector
})
export class ChangeColorDirective {

  constructor(elem: ElementRef, renderer: Renderer2) {
    renderer.setStyle(elem.nativeElement, 'color', 'orange');
  }
}


@Component({                                        //AssistedPractice 1,2,3,4
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor() { }

  productname=[];
  code=[];
  ngOnInit() {
    this.productname=[
      {name:'Leaf Rake'},
      {name:'Garden Cart'},
      {name:'Hammer'},
      {name:'Saw'}
    ];
    this.code=[
      {codeno:'GDN-0011'},
      {codeno:'GDN-0023'},
      {codeno:'TBX-0048'},
      {codeno:'TBX-0022'},
    ];
  }

  images =[];
  toggleImage(){
  this.images = [
  {src:'https://5.imimg.com/data5/TQ/BG/MY-10171564/falcon-premium-plastic-leaf-rake-500x500.jpg', alt:'Leaf rake image'},
  {src:'https://pyxis.nymag.com/v1/imgs/742/966/0471986284a1fad1985a37e49f3be0d269.rsquare.w600.jpg', alt:'Garden Cart image'},
  {src:'https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Claw-hammer.jpg/290px-Claw-hammer.jpg', alt:'hammer image'},
  {src:'https://m.media-amazon.com/images/I/71upa7AM8FL._SX522_.jpg', alt:'saw image'}
  ];
  }
}

