import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  //template: '<app-products></app-products>',                         //AssistedPractice 1,2,3,4,7,8
  //templateUrl: './app.component.html',                               //AssistedPractice 5
  //template : '<app-formvalidation></app-formvalidation>',            //AssistedPractice 6
  template:'<app-routing></app-routing>',                              //AssistedPractice 9
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-app';
  public cdata: string;
}
