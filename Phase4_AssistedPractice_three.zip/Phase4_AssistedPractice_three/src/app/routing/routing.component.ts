import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({                                        //AssistedPractice 9
  selector: 'app-routing',
  templateUrl: './routing.component.html',
  styleUrls: ['./routing.component.css']
})
export class RoutingComponent {

  constructor(private formBuilder: FormBuilder) { }
  title = 'angCare';
  status = 'You haven\'t signed up yet';
  name = '';
  
  ontyping(event:Event) { 
    this.name = (<HTMLInputElement>event.target).value;
  }

  signup() {
     this.status = 'Oops! We are working on it!'; 
  }
  
}
    
