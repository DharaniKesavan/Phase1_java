import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule} from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductsComponent } from './products/products.component';
import { ChildComponent } from './child/child.component';
import { FormvalidationComponent } from './formvalidation/formvalidation.component';
import { ChangeColorDirective } from  './products/products.component';
import { ConvertToSpacesPipe } from 'src/app/products/convert-to-spaces.pipe';
import { SignupComponent } from './signup/signup.component';
import { RoutingComponent } from './routing/routing.component';

const routes: Routes = [{   
  path:'signup',
  component:SignupComponent
}   
]

@NgModule({
  declarations: [
    AppComponent,
    ProductsComponent,
    ChildComponent,
    FormvalidationComponent,
    ChangeColorDirective,
    ConvertToSpacesPipe,
    SignupComponent,
    RoutingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
