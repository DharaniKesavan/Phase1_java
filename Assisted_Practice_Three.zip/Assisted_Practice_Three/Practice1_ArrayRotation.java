package Assisted_Practice_Three;

class Rotate{ 
	public void rotate(int[] rot, int n){		//n - steps = 5
		if(n > rot.length){
   			n = n%rot.length;
		}
		
 		int[] res = new int[rot.length];
 		for(int i=0; i < n; i++){
        	res[i] = rot[rot.length-n+i];
 		}
 		
 		int j=0;
    	for(int i=n; i < rot.length; i++){
        	res[i] = rot[j];
        	j++;
    	}
    	System.out.print("After array rotated by 5 steps = ");
		for(int i=0;i<res.length;i++){
			System.out.print(res[i]+" ");
		}
	}
} 
public class Practice1_ArrayRotation
{
	public static void main(String[] args) {
		Rotate r = new Rotate();
        int arr[] = { 10,15,20,25,30,35,40,45 };								//{ 10,15,20,25,30,35,40,45 }; 
		r.rotate(arr, 5); 	
	}
}

