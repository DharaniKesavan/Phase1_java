package Assisted_Practice_Three;

public class Practice8_Stack {
	final int MAX = 1000; 
	int top; 
	int a[] = new int[MAX];  
	
	Practice8_Stack () { 
		top = -1; 
	} 
	boolean isEmpty() { 
		return (top < 0); 
	} 	
	
	boolean push(int x) { 
		if (top >= (MAX-1)) { 
			System.out.println("Stack Overflow"); 
			return false; 
		} 
		else{ 
			a[++top] = x; 
			System.out.println("pushed into stack = "+x); 
			return true; 
		} 
	} 
	boolean pop() { 
		if (top < 0) { 
			System.out.println("Stack Underflow"); 
			return false; 
		} 
		else{ 
			int x = a[top--]; 
			System.out.println("Popped from stack = "+x);
			return true; 
		} 
	} 

	public static void main(String args[]){
		Practice8_Stack s = new Practice8_Stack (); 
		s.push(11); 
		s.push(22); 
		s.push(33); 
		s.pop();
		 
	}
} 	

