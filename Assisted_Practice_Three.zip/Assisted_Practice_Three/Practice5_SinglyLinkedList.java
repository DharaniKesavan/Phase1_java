package Assisted_Practice_Three; 

public class Practice5_SinglyLinkedList {
	Node head;
	static class Node{ 
		int data; 		
		Node next; 
		Node(int d){ 
			data = d; 
			next = null; 
		} 
	} 
//Insert a new node 
	public static Practice5_SinglyLinkedList insert(Practice5_SinglyLinkedList list, int data){  
		Node new_node = new Node(data); 
		new_node.next = null;  
		
		if (list.head == null){ 
			list.head = new_node; 
		} 
		else {  
        	Node last = list.head; 
       		while (last.next != null) { 
       			last = last.next; 
        	}  
       		last.next = new_node; 
    	} 
   		return list; 
	} 
	
	public static void print(Practice5_SinglyLinkedList list) {	 
		Node currNode = list.head; 
		System.out.print("LinkedList: ");  
		while (currNode != null) {  
			System.out.print(currNode.data + " ");  
			currNode = currNode.next; 
		} 
		System.out.println(); 
	} 
 
	public static Practice5_SinglyLinkedList delete(Practice5_SinglyLinkedList list, int key) {  
		Node currNode = list.head, prev = null; 
		if (currNode != null && currNode.data == key) { 
			list.head = currNode.next; 
			System.out.println(key + " found and deleted"); 
			return list; 
		} 
		while (currNode != null && currNode.data != key) { 
			prev = currNode; 
			currNode = currNode.next; 
		}
		if (currNode != null) { 
			prev.next = currNode.next; 
			System.out.println(key + " found and deleted"); 
		} 
		if (currNode == null) { 
			System.out.println(key + " not found"); 
		} 
		return list; 
	} 
	
	public static void main(String[] args) { 
		Practice5_SinglyLinkedList list = new Practice5_SinglyLinkedList(); 
    		// Insert the values 
    		list = insert(list, 1); 
    		list = insert(list, 3); 
    		list = insert(list, 5); 
    		list = insert(list, 7); 
    		list = insert(list, 9); 
    		list = insert(list, 11); 
    		list = insert(list, 13); 
    		list = insert(list, 15);
    		
    		print(list);  		 
    		delete(list,3);     		 
    		print(list);     		 
    		delete(list,4);     		 
    		print(list);     		 
    		delete(list,13);     		 
    		print(list); 
	} 
}
