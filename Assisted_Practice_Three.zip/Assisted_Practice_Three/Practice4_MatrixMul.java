package Assisted_Practice_Three;

public class Practice4_MatrixMul {
	
	public static int[][] multiply(int[][] Matrix1, int[][] Matrix2, int r1, int c1, int c2){
		int[][] product = new int[r1][c2];
		for(int i = 0; i < r1; i++) {
			for (int j = 0; j < c2; j++) {
    			for (int k = 0; k < c1; k++) {
    				product[i][j] += Matrix1[i][k] * Matrix2[k][j];
    			}
			}
   	 	}
		return product;
	}
	
	public static void main(String[] args) {
   		int r1 = 3, c1 = 2;
		int r2 = 2, c2 = 3;
		int[][] Matrix1 = { {5,4}, {2,7}, {6,9} };
		int[][] Matrix2 = { {8,2,3}, {1,10,5} };
			
		int[][] product = multiply(Matrix1, Matrix2, r1, c1, c2);
		System.out.println("Product of two matrices = ");
		for(int[] row : product) {
			for (int column : row) {
    			System.out.print(column + "    ");
			}
			System.out.println();
		}
	}
}
