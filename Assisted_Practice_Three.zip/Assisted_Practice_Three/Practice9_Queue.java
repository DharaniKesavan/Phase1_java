package Assisted_Practice_Three;

import java.util.LinkedList;
import java.util.Queue;

public class Practice9_Queue {
	public static void main(String[] args) {
	    
		Queue<String> flowers = new LinkedList<>();
		flowers.add("Lotus");
		flowers.add("Jasmine");
		flowers.add("Lily");
		flowers.add("Sunflower");
		flowers.add("Rose");
	        		
		System.out.println("Queue is : " + flowers);
		System.out.println("Size of Queue : " + flowers.size());
	    System.out.println("Head of Queue : " + flowers.peek());
	    flowers.remove();
	    System.out.println("After removing Head of Queue : " + flowers);
	}
}
