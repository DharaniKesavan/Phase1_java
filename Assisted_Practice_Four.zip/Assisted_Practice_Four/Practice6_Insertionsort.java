package Assisted_Practice_Four;

public class Practice6_Insertionsort {

    public static  void main(String[] args){
        int[] arr = {85,10,55,35,25,15,5,40};
        insertion(arr);
        System.out.println("The sorted elements are:");
        for(int i=0;i<arr.length;i++){
            System.out.println(arr[i]);
        }
    }
    
    public static void insertion(int[] arr){
    	int len = arr.length;
    	for(int j=1;j<len;j++){
    		int key = arr[j];
    		int i=j-1;
    		while ((i>-1) && (arr[i]>key)){
    			arr[i+1]=arr[i];
    			i--;
    		}
    		arr[i+1]=key;
    	}
    }
}

