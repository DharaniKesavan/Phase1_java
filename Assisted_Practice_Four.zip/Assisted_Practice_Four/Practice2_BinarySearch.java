package Assisted_Practice_Four;

import java.util.Scanner;

public class Practice2_BinarySearch {

	public static  void main(String[] args){
		int[] arr = {2,4,6,8,10,12,14,16,18,20};
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the element to be searched = ");
		int key = sc.nextInt();
        int arrlength = arr.length;
        binary(arr,0,key,arrlength);
        sc.close();
    }

	public static void binary(int[] arr, int start, int key, int length){
		int midValue = (start+length)/2;
        while(start<=length){
            if(arr[midValue]<key){
                start = midValue + 1;
            } 
            else if(arr[midValue]==key){
                System.out.println("Search Element "+key+" is found at index : "+midValue);
                break;
            }
            else {
                length = midValue-1;
            }
            midValue = (start+length)/2;
        }
        if(start>length){
        	System.out.println("Search Element is not found");
        }
	}
}

