package Assisted_Practice_Four;

public class Practice5_Bubblesort {

	public static void main(String[] args){
		int[] arr= {96,6,32,78,12,4,82,55};
		bubble(arr);
		System.out.println("The sorted elements are:");
		for(int i=0;i<arr.length;i++){
			System.out.println(arr[i]);
		}
	}

    public static void bubble(int[] arr){
        int len = arr.length;
        int temp = 0;
        for(int i=0;i<len;i++){
        	for (int j=1;j<(len);j++){
        		if(arr[j-1]>arr[j]){
        			temp = arr[j-1];
        			arr[j-1]= arr[j];
        			arr[j]= temp;
                }
            }
        }
    }
}

