package Assisted_Practice_Four;

import java.util.Scanner;

public class Practice1_LinearSearch {

   public static void main(String[] args){
	   
	   int[] arr = {3,7,9,4,14,2,20,37,53};
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Enter the element to be searched");
	   int searchValue = sc.nextInt();
	   int result = (int) linear(arr,searchValue);

	   if(result==-1){
		   System.out.println("Search Element not in the array");
	   } 	
	   else {
		   System.out.println("Search Element "+arr[result]+" is found at index "+result);
	   }
	   sc.close();
   }	

   public static int linear(int arr[], int x) {

	   int arrlength = arr.length;
	   for (int i = 0; i < arrlength - 1; i++) {
		   if (arr[i] == x) {
			   return i;	
		   }		
	   }	
	   return -1;
   }	
}


