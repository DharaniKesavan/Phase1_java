package Assisted_Practice_Four;

import java.util.Arrays;
import java.util.Scanner;

public class Practice3_ExponentialSearch {

	public static  void main(String args[]){
		int[] arr = {3,6,8,12,17,21,27,35};
		int length= arr.length;
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the element to be searched = ");
		int value = sc.nextInt();
		int result = exponential(arr,length,value);

		if(result<0)
			System.out.println( "Search Element is not present in the array");
		else 
			System.out.println( "Search Element "+value+" is  present in the array at index : "+result);
		
		sc.close();
	}

    public static int exponential(int[] arr ,int length, int value ){
    	if(arr[0]==value){	
    		return 0;
        }
        int i=1;
        
        while(i<length && arr[i]<=value){
            i=i*2;
        }
        return Arrays.binarySearch(arr,i/2,Math.min(i,length),value);
    }
}

