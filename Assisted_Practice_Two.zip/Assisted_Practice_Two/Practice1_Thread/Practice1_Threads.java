package Assisted_Practice_Two;


public class Practice1_Threads extends Thread {
	public void run(){ 
		int a =10;
		int b =20;
		System.out.println("This is thread class");  
		System.out.println("Addition = "+(a+b)); 
	}  
			
	public static void main(String args[]){  
		Practice1_Threads t1 = new Practice1_Threads();  
		t1.start();                          
	}  
}

