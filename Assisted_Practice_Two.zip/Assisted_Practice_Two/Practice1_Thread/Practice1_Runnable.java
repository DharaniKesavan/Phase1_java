package Assisted_Practice_Two;

public class Practice1_Runnable implements Runnable{  	
    public static int myCount = 0;
    public Practice1_Runnable(){
         
    }
    
    public void run() {
        while(myCount < 10){
            try{
                System.out.println("Thread : "+(++myCount));
                Thread.sleep(1000);		// 1000 miliseconds = 1 sec
            } 
            catch (InterruptedException ie) {
                System.out.println("Error : "+ie.getMessage());
            }
        }
        System.out.println("Exit");
    } 
    
    public static void main(String a[]){
        Practice1_Runnable mrt = new Practice1_Runnable();
        Thread t = new Thread(mrt);
        t.start();
   }
}



