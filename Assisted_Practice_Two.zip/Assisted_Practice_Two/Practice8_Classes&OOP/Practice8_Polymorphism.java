package Assisted_Practice_Two;

public class Practice8_Polymorphism {
	
	    public int sum(int a, int b) 
	    { 
	        return (a + b); 
	    } 
	    public int sum(int a, int b, int c) 
	    { 
	        return (a + b + c); 
	    } 
	    public float sum(float a, float b) 
	    { 
	        return (a + b); 
	    } 
	    public static void main(String args[]) 
	    { 
	    	Practice8_Polymorphism p = new Practice8_Polymorphism(); 
	        System.out.println(p.sum(50,10)); 
	        System.out.println(p.sum(15,45,60)); 
	        System.out.println(p.sum(15.5f,20.5f)); 
	    } 
}

