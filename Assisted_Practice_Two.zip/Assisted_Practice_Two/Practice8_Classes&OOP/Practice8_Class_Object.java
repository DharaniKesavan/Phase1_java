package Assisted_Practice_Two;

public class Practice8_Class_Object {		//Class
	public int AreaofRectangle(int l,int b){
		int a = l*b;
		return a;
	}
	public float AreaofCircle(int r){
		float a = (float)3.14*r*r;
		return a;
	}
	
	public static void main(String args[]){
		Practice8_Class_Object ar = new Practice8_Class_Object();	//Object
		System.out.println("Area of Rectangle = "+ar.AreaofRectangle(5,4));
		System.out.println("Area of Circle = "+ar.AreaofCircle(3));
	}
}
