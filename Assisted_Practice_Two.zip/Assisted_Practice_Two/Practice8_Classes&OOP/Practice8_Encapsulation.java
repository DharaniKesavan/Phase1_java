package Assisted_Practice_Two;

public class Practice8_Encapsulation {
    private String Name; 
    private int Roll; 
    private int Age;
    public int getAge()  
    { 
      return Age; 
    } 
    public String getName()  
    { 
      return Name; 
    } 
    public int getRoll()  
    { 
       return Roll; 
    } 
    public void setAge( int newAge) 
    { 
      Age = newAge; 
    } 
    public void setName(String newName) 
    { 
      Name = newName; 
    } 
    public void setRoll( int newRoll)  
    { 
      Roll = newRoll; 
    } 
  
    public static void main (String[] args)  
    { 
    	Practice8_Encapsulation en = new Practice8_Encapsulation(); 
        en.setName("Ram"); 
        en.setAge(25); 
        en.setRoll(40); 
        System.out.println("My name: " + en.getName()); 
        System.out.println("My age: " + en.getAge()); 
        System.out.println("My roll: " + en.getRoll());      
    } 
}
