package Assisted_Practice_Two;

class Product {		
	int count = 90;
	int price = 30;
	int id = 78;
	String name = "Amul";
		
	void display(){
		System.out.println("Id = "+id+"\n"+"Name = "+name);
	}
	
	void calculate(){
		int	total_price = count*price;
		System.out.println("Total price of Product class = "+total_price);
	}
}
	
class A extends Product{
	int count = 50;
	int price = 10;
	String category = "butter";
	
	void display1(){
		System.out.println("Count = "+count+"\n"+"Category = "+category);
	}
	
	void calculate1(){
		int	total_price = count*price;
		System.out.println("Total price of A class = "+total_price);
	}
}

public class Practice8_Inheritance {
	public static void main(String args[]){
		A a = new A();
		a.display();		
		a.display1();
		a.calculate();
		a.calculate1();
	}
}

