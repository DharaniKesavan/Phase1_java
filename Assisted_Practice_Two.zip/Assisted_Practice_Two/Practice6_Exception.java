package Assisted_Practice_Two;

public class Practice6_Exception {
	public static void main(String args[]){
		try{
			System.out.println("Try block");
			throw new MyException("This is My error Message");
		}
		catch(MyException exp){
			System.out.println("Catch Block") ;
			System.out.println("MyException Occurred: "+exp.getMessage()) ;
		}
	}
}

class MyException extends Exception{	
	String str1;
	MyException(String str2) {
		super(str2);
	}	
	private static final long serialVersionUID = 1L;
}

