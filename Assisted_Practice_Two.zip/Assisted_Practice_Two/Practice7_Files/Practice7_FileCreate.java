package Assisted_Practice_Two;

import java.io.File;

public class Practice7_FileCreate {
	 public static void main(String args[]) throws Exception{
		try {  
		   File file = new File("D:\\Simplilearn_course\\course.txt");
		            
		   if (file.createNewFile()) {  
		       System.out.println("New File is created!");  
		   } 
		   else if(file.exists()) { 
			   System.out.println("File already exists!"); 
		   }
		   else{}
		}
		catch(Exception e){
			e.getMessage();
		}
	 }
	 
}
