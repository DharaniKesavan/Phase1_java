package Assisted_Practice_Two;

import java.io.IOException; 
import java.nio.file.*; 
	  
public class Practice7_FileDelete 
{ 
    public static void main(String[] args)throws Exception{     
        try
        { 
            Files.deleteIfExists(Paths.get("D:\\Simplilearn_course\\core")); 
            System.out.println("File deleted successfully!"); 
        } 
        catch(NoSuchFileException e) 
        { 
            System.out.println("No such file/directory exists"); 
        } 
        catch(DirectoryNotEmptyException e) 
        { 
            System.out.println("Directory is not empty"); 
        } 
        catch(IOException e) 
        { 
            System.out.println("Invalid permissions"); 
        } 
          
        
    } 
}

