package Assisted_Practice_Two;

import java.io.FileReader;

public class Practice7_FileRead { 
	 public static void main(String args[])throws Exception{ 
		 try{
	          FileReader fr = new FileReader("D:\\Simplilearn_course\\course.txt");    
	          int i;    
	          while((i=fr.read())!=-1)    
	          System.out.print((char)i);    
	          fr.close();    
	     } 
		 catch(Exception e){
			 e.getMessage();
		 }    	         
	}
}
