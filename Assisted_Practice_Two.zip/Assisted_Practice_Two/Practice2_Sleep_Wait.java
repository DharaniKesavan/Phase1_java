package Assisted_Practice_Two;

public class Practice2_Sleep_Wait {
	
	public static Object ob = new Object();
    public static void main(String args[]) throws InterruptedException{
    	try{
    		Thread.sleep(1000);
    		System.out.println("Thread is woken after sleeping for 1 sec = "+ Thread.currentThread().getName());
    		synchronized (ob) 
    		{
    			ob.wait(1000);
    			System.out.println("Object is woken after waiting for 1 sec = "+ob);
    		}
    	}
    	catch(InterruptedException ie){
    		ie.getMessage();
    	}
    }
}

