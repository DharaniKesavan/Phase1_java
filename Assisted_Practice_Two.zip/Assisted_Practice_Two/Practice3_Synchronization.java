package Assisted_Practice_Two;
	
class Table{  
		  
	void printTable(int n){  	
		
		System.out.println("This is printTable method");
		synchronized(this){
		    for(int i=1;i<=5;i++){  
		      System.out.println(n*i);  
		      try{  
		       Thread.sleep(400);  
		      }
		      catch(Exception e){
		    	  System.out.println(e);}  
		    }  
		}  	   
	}
}  
		  
class MyThread1 extends Thread{  
	Table t;  
	MyThread1(Table t){  
		this.t=t;  
	}  
	public void run(){  
		System.out.println("This is MyThread1 run() method");
		t.printTable(20);  
	}  	  
}  

class MyThread2 extends Thread{  
	Table t;  
	MyThread2(Table t){  
		this.t=t;  
	}  
	public void run(){  
		System.out.println("This is MyThread2 run() method");
		t.printTable(50);  
	}  
}  
		  
public class Practice3_Synchronization { 
	public static void main(String args[]){  
		
		Table ob = new Table();  
		
		MyThread1 t1 = new MyThread1(ob);  
		MyThread2 t2 = new MyThread2(ob);  
		
		t1.start();  
		t2.start();  
	}  
}  

