package Assisted_Practice_Two;

class throw_Keyword{
    int a=20,b=0;  
    void throwmethod(){
     try{
        if(b==0)        
        throw new ArithmeticException("Can't divide by zero");
     }
     catch(ArithmeticException ex){
        System.out.print("\nException occured : " + ex.getMessage());
     }
     finally{
         int rs = a + b;
         System.out.print("\nThis is finally block");
         System.out.print("\nThe result is = " + rs);
     }
   }
}
//-------------------------------------------------------------------------

class throws_Keyword{
	void throwsmethod() throws ArithmeticException{
		int a=60,b=0,rs;
		try{
			rs = a / b;
			System.out.print("\nThe result is : " + rs);
		}
		catch(ArithmeticException e)   {
			System.out.print("\nException occured : " + e.getMessage());
		}
	}
}
//--------------------------------------------------------------------------	

class CustomException{  
	void validate(int age)throws InvalidAgeException{  
		try{
			if(age<18)  
				  throw new InvalidAgeException("Invalid age");  
			else  
				  System.out.println("\nwelcome to vote"); 
		}
		catch(Exception m){
		   System.out.println("\nException occured : "+ m.getMessage());
		}
	}  
}  
class InvalidAgeException extends Exception{ 
		InvalidAgeException(String s){ 
			super(s);  
		} 
		private static final long serialVersionUID = 1L;
}  
//----------------------------------------------------------------------------

public class Practice5_Throws_CustomExp {
	public static void main(String args[]) throws InvalidAgeException{
		throw_Keyword t1 = new throw_Keyword();
		throws_Keyword t2 = new throws_Keyword();
		CustomException t3 = new CustomException();
		t1.throwmethod();
		t2.throwsmethod();
		t3.validate(15);	
	}
}
