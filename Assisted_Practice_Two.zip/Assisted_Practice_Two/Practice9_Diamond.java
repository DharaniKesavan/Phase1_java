package Assisted_Practice_Two;

interface First {  
    default void show() { 
        System.out.println("Default First"); 
    } 
} 
	
interface Second {  
    default void show() { 
        System.out.println("Default Second"); 
    } 
}  

public class Practice9_Diamond implements First, Second {  
    public void show() {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]){      
    	Practice9_Diamond d = new Practice9_Diamond(); 
        d.show(); 
    } 
}

